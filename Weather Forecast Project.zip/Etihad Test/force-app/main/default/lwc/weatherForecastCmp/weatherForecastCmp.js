import { LightningElement,wire,track } from 'lwc';
import fetchWeatherDetails from '@salesforce/apex/WeatherForecastCls.fetchWeatherDetails';
import fetchWeatherCoordinate from '@salesforce/apex/WeatherForecastCls.fetchWeatherCoordinate';

export default class WeatherForecastCmp extends LightningElement {
    @track inputTerm;
    @track record;
    @track error;
    @track errorFlag = false;
    @track showRecordFlag = false;
    @track mapMarkers = [];   
    @track strLatitude = '';
    @track strLongitude = '';
    @track strError = '';

    // init method to load the location coordinates
    connectedCallback() {
        navigator.geolocation.getCurrentPosition(
                (position) => {   
                    this.mapMarkers = [
                        {
                            location: {
                                'Latitude': position.coords.latitude,
                                'Longitude': position.coords.longitude
                            },
                            title: "My Location",
                        },
                    ]
                  this.strLatitude = position.coords.latitude;
                  this.strLongitude = position.coords.longitude;                 
                },
                (e) => {
                  this.strError = e.message;
                },
                {
                  enableHighAccuracy: true,
                }
        );      
    }

    // Method to assign to param when input field has a change in value
    onNameChange(e) {
        this.inputTerm = e.target.value;
    }
    
    // Method to get weather forecast for when the name of the city is entered
    findForecast() {      
        fetchWeatherDetails({param: this.inputTerm})        
            .then(result => {    
                console.log(result.message);             
                if(result.message != undefined)
                {                   
                    this.errorFlag = true;
                    this.showRecordFlag = false;
                    this.error = result.message;
                }
                else
                {
                    this.errorFlag = false;
                    this.showRecordFlag = true;
                    this.record = result;
                }
                
            })
            .catch(error => {
                this.errorFlag = true;
                this.showRecordFlag = false;
                this.error = error;
            });
    }

    // Method to get weather forecast of current user location
    getValue() {          
        fetchWeatherCoordinate({longitude: this.strLongitude, latitude: this.strLatitude})        
        .then(result => {           
            if(result.message != undefined)
                {                   
                    this.errorFlag = true;
                    this.showRecordFlag = false;
                    this.error = result.message;
                }
            else
            {
                this.errorFlag = false;
                this.showRecordFlag = true;
                this.record = result;
            }
            
        })
        .catch(error => {
            this.errorFlag = true;
            this.showRecordFlag = false;
            this.error = error;
        });   
    }
   
}